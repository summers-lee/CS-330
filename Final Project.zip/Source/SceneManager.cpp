///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ================
// This file contains the implementation of the `SceneManager` class, which is 
// responsible for managing the preparation and rendering of 3D scenes. It 
// handles textures, materials, lighting configurations, and object rendering.
//
// AUTHOR: Brian Battersby
// INSTITUTION: Southern New Hampshire University (SNHU)
// COURSE: CS-330 Computational Graphics and Visualization
//
// INITIAL VERSION: November 1, 2023
// LAST REVISED: December 1, 2024
//
// RESPONSIBILITIES:
// - Load, bind, and manage textures in OpenGL.
// - Define materials and lighting properties for 3D objects.
// - Manage transformations and shader configurations.
// - Render complex 3D scenes using basic meshes.
//
// NOTE: This implementation leverages external libraries like `stb_image` for 
// texture loading and GLM for matrix and vector operations.
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/transform.hpp>
#include <cmath>
#include <cstdlib>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  CreateProceduralBoxTexture()
 ***********************************************************/
void SceneManager::CreateProceduralBoxTexture(std::string tag)
{
	const int width = 1024;
	const int height = 1024;
	const int channels = 3; // RGB

	// pixel buffer
	std::vector<unsigned char> pixels(width * height * channels);

	// set a single pixel's RGB value
	auto setPixel = [&](int x, int y, unsigned char r, unsigned char g, unsigned char b)
		{
			if (x < 0 || x >= width || y < 0 || y >= height)
				return;
			int index = (y * width + x) * channels;
			pixels[index + 0] = r;
			pixels[index + 1] = g;
			pixels[index + 2] = b;
		};

	// fill an axis-aligned rectangle
	auto fillRect = [&](int x0, int y0, int x1, int y1, unsigned char r, unsigned char g, unsigned char b)
		{
			for (int y = y0; y < y1; y++)
				for (int x = x0; x < x1; x++)
					setPixel(x, y, r, g, b);
		};

	// fill a rectangle with rounded corners
	auto fillRoundedRect = [&](int x0, int y0, int x1, int y1, int radius, unsigned char r, unsigned char g, unsigned char b)
		{
			for (int y = y0; y < y1; y++)
			{
				for (int x = x0; x < x1; x++)
				{
					// determine if this pixel falls within one of the corner region
					bool insideCorner = true;
					int cornerX = 0, cornerY = 0;

					if (x < x0 + radius && y < y0 + radius)
					{
						cornerX = x0 + radius; cornerY = y0 + radius;
					}
					else if (x >= x1 - radius && y < y0 + radius)
					{
						cornerX = x1 - radius; cornerY = y0 + radius;
					}
					else if (x < x0 + radius && y >= y1 - radius)
					{
						cornerX = x0 + radius; cornerY = y1 - radius;
					}
					else if (x >= x1 - radius && y >= y1 - radius)
					{
						cornerX = x1 - radius; cornerY = y1 - radius;
					}
					else
					{
						insideCorner = false;
					}

					if (insideCorner)
					{
						int dx = x - cornerX;
						int dy = y - cornerY;
						if ((dx * dx + dy * dy) > (radius * radius))
							continue; // outside the rounded corner, skip
					}

					setPixel(x, y, r, g, b);
				}
			}
		};

	// small local helper - fill a filled circle
	auto fillCircle = [&](int cx, int cy, int radius, unsigned char r, unsigned char g, unsigned char b)
		{
			for (int y = cy - radius; y <= cy + radius; y++)
			{
				for (int x = cx - radius; x <= cx + radius; x++)
				{
					int dx = x - cx;
					int dy = y - cy;
					if ((dx * dx + dy * dy) <= (radius * radius))
						setPixel(x, y, r, g, b);
				}
			}
		};

	// simple 5x7 blocky bitmap font
	static const char* FONT_C[7] = { "01111","10000","10000","10000","10000","10000","01111" };
	static const char* FONT_H[7] = { "10001","10001","10001","11111","10001","10001","10001" };
	static const char* FONT_E[7] = { "11111","10000","10000","11110","10000","10000","11111" };
	static const char* FONT_S[7] = { "01111","10000","10000","01110","00001","00001","11110" };

	// look up the 5x7 pattern for one supported letter
	auto getFontPattern = [&](char ch) -> const char**
		{
			switch (ch)
			{
			case 'C': return FONT_C;
			case 'H': return FONT_H;
			case 'E': return FONT_E;
			case 'S': return FONT_S;
			default:  return nullptr;
			}
		};

	// draws one blocky character, rotated 
	auto drawCharDiagonal = [&](char ch, float ox, float oy, int scale, float angleDegrees,
		unsigned char r, unsigned char g, unsigned char b)
		{
			const char** pattern = getFontPattern(ch);
			if (pattern == nullptr)
				return;

			float angle = angleDegrees * 3.14159265f / 180.0f;
			float cosA = cosf(angle);
			float sinA = sinf(angle);

			for (int row = 0; row < 7; row++)
			{
				for (int col = 0; col < 5; col++)
				{
					if (pattern[row][col] == '1')
					{
						float lx = (float)(col * scale);
						float ly = (float)(row * scale);

						for (int dy = 0; dy < scale; dy++)
						{
							for (int dx = 0; dx < scale; dx++)
							{
								float px = lx + dx;
								float py = ly + dy;

								// rotate this pixel around the character's
								float rx = px * cosA - py * sinA;
								float ry = px * sinA + py * cosA;

								setPixel((int)(ox + rx), (int)(oy + ry), r, g, b);
							}
						}
					}
				}
			}
		};

	//  draws a short word diagonally
	auto drawWordDiagonal = [&](const std::string& word, float startX, float startY,
		int scale, float angleDegrees, unsigned char r, unsigned char g, unsigned char b)
		{
			float angle = angleDegrees * 3.14159265f / 180.0f;
			float cosA = cosf(angle);
			float sinA = sinf(angle);

			// 5 columns + 1 column of spacing per character, scaled
			float advance = (float)((5 + 1) * scale);

			float cx = startX;
			float cy = startY;

			for (char ch : word)
			{
				drawCharDiagonal(ch, cx, cy, scale, angleDegrees, r, g, b);
				cx += advance * cosA;
				cy += advance * sinA;
			}
		};

	// base cardboard/yellow body,
	srand(42);
	for (int y = 0; y < height; y++)
	{
		for (int x = 0; x < width; x++)
		{
			// base warm yellow color
			float baseR = 232.0f, baseG = 184.0f, baseB = 58.0f;

			// fine grain noise
			float noise = (float)((rand() % 21) - 10); // -10..+10

			// faint corrugated cardboard lines
			float flute = sinf((float)y / 6.0f) * 2.5f;

			float r = baseR + noise + flute;
			float g = baseG + noise + flute;
			float b = baseB + noise + flute;

			r = (r < 0.0f) ? 0.0f : (r > 255.0f ? 255.0f : r);
			g = (g < 0.0f) ? 0.0f : (g > 255.0f ? 255.0f : g);
			b = (b < 0.0f) ? 0.0f : (b > 255.0f ? 255.0f : b);

			setPixel(x, y, (unsigned char)r, (unsigned char)g, (unsigned char)b);
		}
	}

	// blue banner stripe across the top
	int bannerTop = (int)(height * 0.06f);
	int bannerBottom = (int)(height * 0.22f);
	fillRect(0, bannerTop, width, bannerBottom, 30, 70, 140);

	// thin red accent line under the banner
	fillRect(0, bannerBottom, width, bannerBottom + 6, 210, 40, 40);

	// rounded "product photo" zone
	int photoTop = (int)(height * 0.34f);
	int photoBottom = (int)(height * 0.80f);
	int photoLeft = (int)(width * 0.10f);
	int photoRight = (int)(width * 0.90f);

	// off-white panel background to frame the "photo"
	fillRoundedRect(photoLeft, photoTop, photoRight, photoBottom, 24, 250, 248, 240);

	// creamy/cheesy blob 
	int blobTop = bannerBottom;
	int blobBottom = photoBottom - 4;
	int blobLeft = photoLeft + 4;
	int blobRight = photoRight - 4;

	for (int y = blobTop; y < blobBottom; y++)
	{
		for (int x = blobLeft; x < blobRight; x++)
		{
			float nx = (float)(x - blobLeft) / (float)(blobRight - blobLeft);
			float ny = (float)(y - blobTop) / (float)(blobBottom - blobTop);

			// smooth blob value using a couple of overlapping sine waves
			float blob = 0.5f + 0.5f * sinf(nx * 6.0f + ny * 4.0f) * cosf(ny * 5.0f - nx * 3.0f);

			float creamR = 245.0f, creamG = 210.0f, creamB = 120.0f;
			float goldR = 225.0f, goldG = 165.0f, goldB = 60.0f;

			float r = creamR * (1.0f - blob) + goldR * blob;
			float g = creamG * (1.0f - blob) + goldG * blob;
			float b = creamB * (1.0f - blob) + goldB * blob;

			setPixel(x, y, (unsigned char)r, (unsigned char)g, (unsigned char)b);
		}
	}

	// product subtitle - drawn AFTER the blob so it stays visible on top
	int subY = (int)(height * 0.40f);
	int subH = (int)(height * 0.035f);
	fillRoundedRect((int)(width * 0.12f), subY, (int)(width * 0.62f), subY + subH, 6, 90, 85, 70);

	// thin border outline around the photo panel. 
	fillRect(photoLeft, photoBottom - 4, photoRight, photoBottom, 120, 90, 40);
	fillRect(photoLeft, photoTop, photoLeft + 4, photoBottom, 120, 90, 40);
	fillRect(photoRight - 4, photoTop, photoRight, photoBottom, 120, 90, 40);

	// diagonal red blocky pixel
	drawWordDiagonal("CHEESE", 120.0f, 560.0f, 20, 18.0f, 210, 30, 30);

	// badge circle - moved to sit at/near the end of the CHEESE text
	int badgeCX = 846;
	int badgeCY = 776;
	int badgeR = 46;
	fillCircle(badgeCX, badgeCY, badgeR + 4, 120, 20, 20); 
	fillCircle(badgeCX, badgeCY, badgeR, 210, 40, 40);     

	// 3 light-blue squares on the TOP banner's right side
	{
		const int squareSize = 70;
		const int squareGap = 16;
		const int numSquares = 3;
		const int squaresRightMargin = 40;
		int totalW = numSquares * squareSize + (numSquares - 1) * squareGap;
		int startX = width - squaresRightMargin - totalW;
		int squareY = bannerTop + ((bannerBottom - bannerTop) - squareSize) / 2;

		for (int i = 0; i < numSquares; i++)
		{
			int sx = startX + i * (squareSize + squareGap);
			fillRoundedRect(sx, squareY, sx + squareSize, squareY + squareSize, 10, 120, 190, 230);
		}
	}
	
	// upload the finished pixel buffer to OpenGL
	GLuint textureID = 0;
	glGenTextures(1, &textureID);
	glBindTexture(GL_TEXTURE_2D, textureID);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// our buffer is packed tightly (width * 3 bytes per row)
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, pixels.data());
	glGenerateMipmap(GL_TEXTURE_2D);

	glBindTexture(GL_TEXTURE_2D, 0);

	// register the generated texture under the given tag
	m_textureIDs[m_loadedTextures].ID = textureID;
	m_textureIDs[m_loadedTextures].tag = tag;
	m_loadedTextures++;

	std::cout << "Successfully generated procedural texture: " << tag
		<< ", width:" << width << ", height:" << height << std::endl;
}
 /***********************************************************
  *  LoadSceneTextures()
  *
  *  This method is used for preparing the 3D scene by loading
  *  the shapes, textures in memory to support the 3D scene
  *  rendering
  ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	CreateGLTexture("textures/wood.jpg", "wood");
	CreateGLTexture("textures/greywood.jpg", "greywood");
	CreateGLTexture("textures/windows.jpg", "windows");
	CreateProceduralBoxTexture("cardboard_procedural");
	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the various material
 *  settings for all of the objects within the 3D scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// material for the wood objects (mallet, tray) - fairly matte, low shine
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.diffuseColor = glm::vec3(0.5f, 0.4f, 0.3f);
	woodMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	woodMaterial.shininess = 8.0f;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	// material for the table - fairly matte, low shine
	OBJECT_MATERIAL greywoodMaterial;
	greywoodMaterial.diffuseColor = glm::vec3(0.55f, 0.55f, 0.55f);  // neutral grey, not warm
	greywoodMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	greywoodMaterial.shininess = 8.0f;
	greywoodMaterial.tag = "greywood";
	m_objectMaterials.push_back(greywoodMaterial);

	// material for the ceramic mug - smoother, brighter highlight
	OBJECT_MATERIAL ceramicMaterial;
	ceramicMaterial.diffuseColor = glm::vec3(0.9f, 0.9f, 0.88f);
	ceramicMaterial.specularColor = glm::vec3(0.8f, 0.8f, 0.8f);
	ceramicMaterial.shininess = 45.0f;
	ceramicMaterial.tag = "ceramic";
	m_objectMaterials.push_back(ceramicMaterial);

	// material for the cardboard box - dull, almost no specular highlight
	OBJECT_MATERIAL cardboardMaterial;
	cardboardMaterial.diffuseColor = glm::vec3(0.6f, 0.5f, 0.3f);
	cardboardMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	cardboardMaterial.shininess = 2.0f;
	cardboardMaterial.tag = "cardboard";
	m_objectMaterials.push_back(cardboardMaterial);

	// material for the background window plane - flat, almost no specular,
	OBJECT_MATERIAL windowMaterial;
	windowMaterial.diffuseColor = glm::vec3(0.9f, 0.9f, 0.9f);
	windowMaterial.specularColor = glm::vec3(0.0f, 0.0f, 0.0f);
	windowMaterial.shininess = 1.0f;
	windowMaterial.tag = "window";
	m_objectMaterials.push_back(windowMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is used for configuring the light sources for
 *  the 3D scene.  The Phong shading model (ambient, diffuse,
 *  specular) requires at least two light sources, one of
 *  which must be a point light, and at least one of which
 *  must be colored.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// turn on the custom lighting calculations in the shader
	m_pShaderManager->setBoolValue("bUseLighting", true);

	/******************************************************
	 *  DIRECTIONAL LIGHT
	 *  Mimics the broad, soft daylight coming through the
	 *  window behind the scene. Slightly cool/white.
	 ******************************************************/
	m_pShaderManager->setVec3Value("directionalLight.direction", glm::vec3(-0.3f, -1.0f, -0.4f));
	m_pShaderManager->setVec3Value("directionalLight.ambient", glm::vec3(0.25f, 0.25f, 0.27f));
	m_pShaderManager->setVec3Value("directionalLight.diffuse", glm::vec3(0.5f, 0.5f, 0.55f));
	m_pShaderManager->setVec3Value("directionalLight.specular", glm::vec3(0.3f, 0.3f, 0.3f));
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	/******************************************************
	 *  POINT LIGHT 0
	 *  A warm colored fill light placed up and to the side,
	 *  near where the window light would be hitting the
	 *  table, satisfying the "colored light" requirement.
	 ******************************************************/
	m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(-6.0f, 8.0f, 6.0f));
	m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.1f, 0.08f, 0.05f));
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(1.0f, 0.85f, 0.6f));
	m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(0.6f, 0.5f, 0.4f));
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	/******************************************************
	 *  POINT LIGHT 1
	 *  A neutral fill light from the front/camera side so
	 *  that no part of any object goes completely dark as
	 *  the camera orbits around the scene.
	 ******************************************************/
	m_pShaderManager->setVec3Value("pointLights[1].position", glm::vec3(4.0f, 6.0f, 10.0f));
	m_pShaderManager->setVec3Value("pointLights[1].ambient", glm::vec3(0.08f, 0.08f, 0.08f));
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", glm::vec3(0.4f, 0.4f, 0.4f));
	m_pShaderManager->setVec3Value("pointLights[1].specular", glm::vec3(0.2f, 0.2f, 0.2f));
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

	// remaining point light slots (2-4) and the spot light are left inactive
	m_pShaderManager->setBoolValue("pointLights[2].bActive", false);
	m_pShaderManager->setBoolValue("pointLights[3].bActive", false);
	m_pShaderManager->setBoolValue("pointLights[4].bActive", false);
	m_pShaderManager->setBoolValue("spotLight.bActive", false);
}


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();
	
	m_basicMeshes->LoadPlaneMesh();

	//Cup, Mallet, and Egg tray holes
	m_basicMeshes-> LoadCylinderMesh();
	
	//Handle for the cup
	m_basicMeshes->LoadTorusMesh();

	//Velveeta box and egg tray
	m_basicMeshes->LoadBoxMesh();
	
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 3.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, -1.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the wood texture and material for the table top
	SetShaderTexture("greywood");
	SetShaderMaterial("wood");
	SetTextureUVScale(4.0f, 2.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	
	/***********************************************************
 *  CUP
 ***********************************************************/
 
	scaleXYZ = glm::vec3(1.0f, 2.0f, 1.0f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, -1.0f, 4.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//sets ceramic material for cup
	SetShaderColor(0.98f, 0.97f, 0.94f, 1.0f);
	SetShaderMaterial("ceramic");

	m_basicMeshes->DrawCylinderMesh();

	/***********************************************************
 *  CUP HANDLE
 ***********************************************************/

	scaleXYZ = glm::vec3(0.3f, 0.65f, 0.30f);

	// Rotate torus so the hole faces outward
	XrotationDegrees = 0.0f;
	YrotationDegrees = 180.0f;
	ZrotationDegrees = 0.0f;

	// Move left of cup
	positionXYZ = glm::vec3(-1.2f, -0.05f, 4.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//sets ceramic material for cup
	SetShaderColor(0.98f, 0.97f, 0.94f, 1.0f);
	SetShaderMaterial("ceramic");
	
	m_basicMeshes->DrawTorusMesh();

/***********************************************************
 *  MALLET HEAD
 ***********************************************************/

	scaleXYZ = glm::vec3(0.45f, 0.90f, 0.45f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// location of mallet head
	positionXYZ = glm::vec3(4.0f, -1.0f, 4.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the wood texture and material
	SetShaderTexture("wood");
	SetShaderMaterial("wood");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	/***********************************************************
 *  MALLET HANDLE
 ***********************************************************/

	scaleXYZ = glm::vec3(0.15f, 3.0f, 0.2f);

	XrotationDegrees = 90.0f;
	YrotationDegrees = -30.0f;
	ZrotationDegrees = -10.0f;

	// location of mallet handle
	positionXYZ = glm::vec3(4.0f, -0.5f, 4.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the wood texture
	SetShaderTexture("wood");
	SetShaderMaterial("wood");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	/***********************************************************
 *  VELVEETA BOX
 ***********************************************************/

	scaleXYZ = glm::vec3(3.6f, 2.7f, 1.05f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 15.0f;
	ZrotationDegrees = 0.0f;

	// location of Velveeta box
	positionXYZ = glm::vec3(-6.0f, 0.35f, -0.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("cardboard_procedural");
	SetShaderMaterial("cardboard");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	/***********************************************************
 *  EGG TRAY BASE
 ***********************************************************/

	scaleXYZ = glm::vec3(3.3f, 0.525f, 2.7f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// location of egg tray
	positionXYZ = glm::vec3(1.5f, -0.7375f, -0.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("wood");
	SetShaderMaterial("wood");
	SetTextureUVScale(2.0f, 2.0f);

	m_basicMeshes->DrawBoxMesh();

	/***********************************************************
 *  EGG TRAY HOLES
 ***********************************************************/
	{
		// local grid offsets relative to the tray center, matching
		// the 2 rows x 3 columns layout in the photo
		const float holeOffsetsX[6] = { -1.125f, 0.0f, 1.125f, -1.125f, 0.0f, 1.125f };
		const float holeOffsetsZ[6] = { -0.675f, -0.675f, -0.675f,  0.675f,  0.675f,  0.675f };

		for (int i = 0; i < 6; i++)
		{
			scaleXYZ = glm::vec3(0.42f, 0.18f, 0.42f);

			XrotationDegrees = 0.0f;
			YrotationDegrees = 0.0f;
			ZrotationDegrees = 0.0f;

			// location of wholes in egg tray
			positionXYZ = glm::vec3(
				1.5f + holeOffsetsX[i],
				-0.575f,
				-0.5f + holeOffsetsZ[i]);

			SetTransformations(
				scaleXYZ,
				XrotationDegrees,
				YrotationDegrees,
				ZrotationDegrees,
				positionXYZ);

			// dark, low-shine color to read visually as a recessed hole
			SetShaderColor(0.08f, 0.06f, 0.05f, 1.0f);
			SetShaderMaterial("wood");

			m_basicMeshes->DrawCylinderMesh();
		}
	}

	/***********************************************************
 *  BACKGROUND WINDOW PLANE
 ***********************************************************/

	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Background wall
	positionXYZ = glm::vec3(0.0f, 9.0f, -10.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("windows");
	SetShaderMaterial("window");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawPlaneMesh();
}